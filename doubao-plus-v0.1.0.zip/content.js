console.log("=== Doubao Plus Content Script Started ===");console.log("URL:",window.location.href);console.log("Timestamp:",new Date().toISOString());const c={container:null,shadowRoot:null,observer:null};chrome.runtime.onMessage.addListener((o,a,e)=>(o.action==="toggle"&&(console.log("Toggle action received"),e({status:"success"})),o.action==="insertPrompt"&&(console.log("Insert prompt action received:",o.content),w(o.content),e({status:"success"})),o.action==="refreshUI"&&(console.log("Refresh UI action received"),m(),e({status:"success"})),!0));function w(o){const a=document.querySelector('textarea[placeholder*="豆包"]')||document.querySelector('textarea[placeholder*="发送"]')||document.querySelector('textarea[placeholder*="输入"]')||document.querySelector('div[contenteditable="true"]');if(a){if(a.tagName==="TEXTAREA"){const e=a.value;a.value=e?`${e}
${o}`:o,a.dispatchEvent(new Event("input",{bubbles:!0})),a.focus()}else{const e=a.textContent||"";a.textContent=e?`${e}
${o}`:o,a.dispatchEvent(new Event("input",{bubbles:!0})),a.focus()}console.log("Prompt inserted successfully")}else console.log("Could not find input element")}function h(){console.log("Searching for sidebar..."),console.log("Document ready state:",document.readyState);const o=['nav[data-testid="chat_route_layout_leftside_nav"]','aside[data-testid="samantha_layout_right_side"]',"aside",'[class*="sidebar"]','[class*="Sidebar"]','[class*="history"]','[class*="History"]','[class*="conversation"]','[class*="Conversation"]','[class*="chat"]','[class*="Chat"]','[class*="list"]','[class*="List"]','[role="navigation"]',"nav",'div[class*="left"]','div[class*="Left"]','div[class*="menu"]','div[class*="Menu"]'];for(const a of o){const e=document.querySelector(a);if(e)return console.log("Found sidebar with selector:",a),console.log("Sidebar element:",e),console.log("Sidebar classes:",e.className),e}return console.log("No sidebar found with any selector"),null}function k(){var t;const o=h();if(!o)return{parent:null,insertBefore:null};console.log("Looking for insert position in sidebar...");const a=['[class*="history-list"]','[class*="HistoryList"]','[class*="chat-list"]','[class*="ChatList"]','[class*="conversation-list"]','[class*="ConversationList"]','[class*="list-item"]','[class*="ListItem"]'];for(const r of a){const n=o.querySelector(r);if(n)return console.log("Found history list:",r),{parent:o,insertBefore:n}}const e=o.querySelectorAll('button, div[role="button"]');for(const r of e){const n=(t=r.textContent)==null?void 0:t.trim();if(n==="更多"||n==="More"){console.log("Found more button:",r);const s=r.nextElementSibling;if(s)return console.log("Will insert after more button, before:",s),{parent:o,insertBefore:s}}}return console.log("Could not find specific insert position, will insert at top of sidebar"),{parent:o,insertBefore:o.firstChild}}function m(){if(c.container){console.log("Doubao Plus UI already injected");return}const{parent:o,insertBefore:a}=k();o||console.log("Could not find sidebar, will inject to body"),console.log("Injecting Doubao Plus UI..."),c.container=document.createElement("div"),c.container.id="doubao-plus-container",o?c.container.style.cssText=`
      width: 100%;
      background: #f9fafb;
      border: 2px solid #3b82f6;
      border-radius: 8px;
      margin: 8px 0;
      overflow: visible;
    `:c.container.style.cssText=`
      position: fixed;
      top: 20px;
      left: 50%;
      transform: translateX(-50%);
      z-index: 99999;
      width: 320px;
      max-height: 600px;
      overflow: auto;
      background: white;
      border-radius: 12px;
      box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1);
    `,c.shadowRoot=c.container.attachShadow({mode:"open"});const e=document.createElement("style");e.textContent=`
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }
    
    .doubao-plus-ui {
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
      background: #ffffff;
      border-bottom: 1px solid #e5e7eb;
      padding: 12px;
    }
    
    .doubao-plus-header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      margin-bottom: 12px;
    }
    
    .doubao-plus-title {
      font-size: 14px;
      font-weight: 600;
      color: #1f2937;
    }
    
    .doubao-plus-tabs {
      display: flex;
      gap: 4px;
      background: #f3f4f6;
      padding: 4px;
      border-radius: 8px;
    }
    
    .doubao-plus-tab {
      flex: 1;
      padding: 6px 12px;
      font-size: 12px;
      font-weight: 500;
      color: #6b7280;
      background: transparent;
      border: none;
      border-radius: 6px;
      cursor: pointer;
      transition: all 0.2s;
    }
    
    .doubao-plus-tab:hover {
      background: #e5e7eb;
    }
    
    .doubao-plus-tab.active {
      background: #ffffff;
      color: #3b82f6;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.05);
    }
    
    .doubao-plus-content {
      max-height: 400px;
      overflow-y: auto;
    }
    
    .doubao-plus-empty {
      text-align: center;
      padding: 24px;
      color: #9ca3af;
      font-size: 13px;
    }
    
    .doubao-plus-btn {
      display: inline-flex;
      align-items: center;
      gap: 6px;
      padding: 6px 12px;
      font-size: 12px;
      font-weight: 500;
      color: #ffffff;
      background: #3b82f6;
      border: none;
      border-radius: 6px;
      cursor: pointer;
      transition: background 0.2s;
    }
    
    .doubao-plus-btn:hover {
      background: #2563eb;
    }
    
    .doubao-plus-btn-secondary {
      background: #f3f4f6;
      color: #374151;
    }
    
    .doubao-plus-btn-secondary:hover {
      background: #e5e7eb;
    }
    
    .doubao-plus-btn-danger {
      background: #ef4444;
    }
    
    .doubao-plus-btn-danger:hover {
      background: #dc2626;
    }
    
    .doubao-plus-input {
      width: 100%;
      padding: 8px 12px;
      font-size: 13px;
      color: #1f2937;
      background: #ffffff;
      border: 1px solid #d1d5db;
      border-radius: 6px;
      outline: none;
      transition: border-color 0.2s;
    }
    
    .doubao-plus-input:focus {
      border-color: #3b82f6;
    }
    
    .doubao-plus-list-item {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 8px 12px;
      margin-bottom: 4px;
      background: #ffffff;
      border: 1px solid #e5e7eb;
      border-radius: 6px;
      cursor: pointer;
      transition: all 0.2s;
    }
    
    .doubao-plus-list-item:hover {
      background: #f9fafb;
      border-color: #d1d5db;
    }
    
    .doubao-plus-list-item-title {
      font-size: 13px;
      color: #1f2937;
      font-weight: 500;
    }
    
    .doubao-plus-list-item-actions {
      display: flex;
      gap: 4px;
    }
    
    .doubao-plus-icon-btn {
      padding: 4px;
      background: transparent;
      border: none;
      border-radius: 4px;
      cursor: pointer;
      color: #6b7280;
      transition: all 0.2s;
    }
    
    .doubao-plus-icon-btn:hover {
      background: #f3f4f6;
      color: #374151;
    }
    
    .doubao-plus-badge {
      display: inline-block;
      padding: 2px 6px;
      font-size: 10px;
      font-weight: 600;
      color: #ffffff;
      background: #3b82f6;
      border-radius: 9999px;
    }
    
    .doubao-plus-folder {
      display: flex;
      align-items: center;
      gap: 8px;
      padding: 8px 12px;
      margin-bottom: 4px;
      background: #ffffff;
      border: 1px solid #e5e7eb;
      border-radius: 6px;
      cursor: pointer;
      transition: all 0.2s;
    }
    
    .doubao-plus-folder:hover {
      background: #f9fafb;
      border-color: #d1d5db;
    }
    
    .doubao-plus-folder-color {
      width: 8px;
      height: 8px;
      border-radius: 50%;
    }
    
    .doubao-plus-folder-name {
      flex: 1;
      font-size: 13px;
      color: #1f2937;
      font-weight: 500;
    }
    
    .doubao-plus-modal {
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background: rgba(0, 0, 0, 0.5);
      display: flex;
      align-items: center;
      justify-content: center;
      z-index: 99999;
    }
    
    .doubao-plus-modal-content {
      background: #ffffff;
      border-radius: 12px;
      padding: 24px;
      max-width: 400px;
      width: 90%;
      box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1);
    }
    
    .doubao-plus-modal-title {
      font-size: 16px;
      font-weight: 600;
      color: #1f2937;
      margin-bottom: 16px;
    }
    
    .doubao-plus-modal-body {
      margin-bottom: 20px;
    }
    
    .doubao-plus-modal-footer {
      display: flex;
      justify-content: flex-end;
      gap: 8px;
    }
    
    .doubao-plus-color-picker {
      display: flex;
      gap: 8px;
      flex-wrap: wrap;
      margin-top: 8px;
    }
    
    .doubao-plus-color-option {
      width: 24px;
      height: 24px;
      border-radius: 50%;
      cursor: pointer;
      border: 2px solid transparent;
      transition: all 0.2s;
    }
    
    .doubao-plus-color-option:hover {
      transform: scale(1.1);
    }
    
    .doubao-plus-color-option.selected {
      border-color: #1f2937;
    }
    
    .doubao-plus-form-group {
      margin-bottom: 16px;
    }
    
    .doubao-plus-form-label {
      display: block;
      font-size: 13px;
      font-weight: 500;
      color: #374151;
      margin-bottom: 6px;
    }
    
    .doubao-plus-textarea {
      width: 100%;
      min-height: 80px;
      padding: 8px 12px;
      font-size: 13px;
      color: #1f2937;
      background: #ffffff;
      border: 1px solid #d1d5db;
      border-radius: 6px;
      outline: none;
      resize: vertical;
      font-family: inherit;
    }
    
    .doubao-plus-textarea:focus {
      border-color: #3b82f6;
    }
    
    .doubao-plus-search {
      width: 100%;
      padding: 8px 12px;
      font-size: 13px;
      color: #1f2937;
      background: #ffffff;
      border: 1px solid #d1d5db;
      border-radius: 6px;
      outline: none;
      margin-bottom: 12px;
    }
    
    .doubao-plus-search:focus {
      border-color: #3b82f6;
    }
    
    .doubao-plus-star {
      color: #f59e0b;
    }
    
    .doubao-plus-star.empty {
      color: #d1d5db;
    }
    
    .doubao-plus-chat-action {
      background: transparent;
      border: none;
      cursor: pointer;
      padding: 4px;
      border-radius: 4px;
      color: #6b7280;
      transition: all 0.2s;
      opacity: 0.6;
    }
    
    .doubao-plus-chat-action:hover {
      opacity: 1;
      background: #f3f4f6;
    }
    
    .doubao-plus-chat-menu {
      position: fixed;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      background: white;
      border-radius: 12px;
      box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.2);
      z-index: 999999;
      min-width: 200px;
    }
    
    .doubao-plus-chat-menu-content {
      padding: 8px 0;
    }
    
    .doubao-plus-chat-menu-item {
      display: flex;
      align-items: center;
      gap: 8px;
      padding: 8px 12px;
      cursor: pointer;
      border-radius: 6px;
      transition: all 0.2s;
    }
    
    .doubao-plus-chat-menu-item:hover {
      background: #f3f4f6;
    }
    
    .doubao-plus-chat-menu-item svg {
      width: 16px;
      height: 16px;
    }
    
    .doubao-plus-chat-menu-item span {
      font-size: 13px;
      color: #374151;
    }
  `,c.shadowRoot.appendChild(e);const t=document.createElement("div");t.className="doubao-plus-ui",t.innerHTML=`
    <div class="doubao-plus-header">
      <div class="doubao-plus-title">🚀 Doubao Plus</div>
      <div class="doubao-plus-tabs">
        <button class="doubao-plus-tab active" data-tab="chats">对话</button>
        <button class="doubao-plus-tab" data-tab="folders">文件夹</button>
        <button class="doubao-plus-tab" data-tab="prompts">提示词</button>
      </div>
    </div>
    <div class="doubao-plus-content" id="doubao-plus-content">
      <div class="doubao-plus-empty">加载中...</div>
    </div>
  `,c.shadowRoot.appendChild(t),o&&a?(o.insertBefore(c.container,a),console.log("Doubao Plus UI injected to sidebar successfully")):o?(o.appendChild(c.container),console.log("Doubao Plus UI appended to sidebar")):(document.body.appendChild(c.container),console.log("Doubao Plus UI injected to body")),C(),b("chats")}function C(){if(!c.shadowRoot)return;const o=c.shadowRoot.querySelectorAll(".doubao-plus-tab");o.forEach(a=>{a.addEventListener("click",()=>{o.forEach(t=>t.classList.remove("active")),a.classList.add("active");const e=a.getAttribute("data-tab");e&&b(e)})})}async function b(o){if(console.log("loadContent called with tab:",o),!c.shadowRoot)return;const a=c.shadowRoot.getElementById("doubao-plus-content");if(!a){console.log("Content element not found");return}switch(console.log("Loading content for tab:",o),o){case"chats":await L(a);break;case"folders":await M(a);break;case"prompts":await S(a);break}}async function L(o){const e=(await chrome.runtime.sendMessage({action:"getChats"})).chats||[];if(e.length===0){o.innerHTML=`
      <div class="doubao-plus-empty">
        <p>暂无保存的对话</p>
        <p style="margin-top: 8px; font-size: 12px;">点击对话列表中的保存按钮来保存对话</p>
      </div>
    `;return}o.innerHTML=`
    <div style="display: flex; gap: 8px; margin-bottom: 12px;">
      <input type="text" class="doubao-plus-search" placeholder="搜索对话..." id="chat-search">
    </div>
    <div id="chats-list"></div>
  `;const t=o.querySelector("#chats-list");t&&e.forEach(n=>{const s=document.createElement("div");s.className="doubao-plus-list-item",s.style.cssText="cursor: pointer;",s.setAttribute("data-chat-url",n.url),s.innerHTML=`
        <div style="flex: 1; min-width: 0;">
          <div class="doubao-plus-list-item-title" style="white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">
            ${n.title}
          </div>
          <div style="font-size: 11px; color: #6b7280; margin-top: 2px;">
            ${new Date(n.timestamp).toLocaleDateString()}
          </div>
        </div>
        <div class="doubao-plus-list-item-actions">
          <button class="doubao-plus-icon-btn" title="星标" data-action="star" data-id="${n.id}">
            <svg class="doubao-plus-star ${n.starred?"":"empty"}" width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
              <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
            </svg>
          </button>
          <button class="doubao-plus-icon-btn" title="删除" data-action="delete" data-id="${n.id}">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M3 6h18M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a2 2 0 012-2h4a2 2 0 012 2v2"/>
            </svg>
          </button>
        </div>
      `,t.appendChild(s),s.addEventListener("click",l=>{l.target.closest(".doubao-plus-icon-btn")||(window.location.href=n.url)})});const r=o.querySelector("#chat-search");r&&r.addEventListener("input",n=>{const s=n.target.value.toLowerCase();o.querySelectorAll(".doubao-plus-list-item").forEach(i=>{var p,u;const d=((u=(p=i.querySelector(".doubao-plus-list-item-title"))==null?void 0:p.textContent)==null?void 0:u.toLowerCase())||"";i.style.display=d.includes(s)?"flex":"none"})}),o.querySelectorAll(".doubao-plus-icon-btn").forEach(n=>{n.addEventListener("click",async s=>{s.stopPropagation();const l=n.getAttribute("data-action"),i=n.getAttribute("data-id");l&&i&&await q(l,i)})})}async function M(o){const e=(await chrome.runtime.sendMessage({action:"getFolders"})).folders||[];o.innerHTML=`
    <button class="doubao-plus-btn" style="width: 100%; margin-bottom: 12px;" id="create-folder-btn">
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <path d="M12 5v14M5 12h14"/>
      </svg>
      创建文件夹
    </button>
    <div id="folders-list"></div>
  `;const t=o.querySelector("#folders-list");if(t)if(e.length===0)t.innerHTML=`
        <div class="doubao-plus-empty">
          <p>暂无文件夹</p>
        </div>
      `;else for(const n of e){const s=document.createElement("div");s.className="doubao-plus-folder",s.setAttribute("data-folder-id",n.id),s.innerHTML=`
          <div class="doubao-plus-folder-content" style="display: flex; align-items: center; gap: 8px; flex: 1;">
            <div class="doubao-plus-folder-toggle" style="cursor: pointer; padding: 4px;">
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M9 18l6-6-6-6"/>
              </svg>
            </div>
            <div class="doubao-plus-folder-color" style="background: ${n.color}"></div>
            <div class="doubao-plus-folder-name">${n.name}</div>
          </div>
          <div class="doubao-plus-list-item-actions">
            <button class="doubao-plus-icon-btn" title="编辑" data-action="edit" data-id="${n.id}">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7"/>
                <path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"/>
              </svg>
            </button>
            <button class="doubao-plus-icon-btn" title="删除" data-action="delete" data-id="${n.id}">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M3 6h18M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a2 2 0 012-2h4a2 2 0 012 2v2"/>
              </svg>
            </button>
          </div>
        `;const l=document.createElement("div");l.className="doubao-plus-folder-chats",l.style.cssText="display: none; padding-left: 24px; margin-top: 8px;";const d=(await chrome.runtime.sendMessage({action:"getChatsByFolder",folderId:n.id})).chats||[];d.length===0?l.innerHTML=`
            <div style="font-size: 12px; color: #9ca3af; padding: 8px 12px;">
              暂无对话
            </div>
          `:d.forEach(u=>{const f=document.createElement("div");f.className="doubao-plus-list-item",f.style.cssText="margin-bottom: 4px; cursor: pointer;",f.setAttribute("data-chat-url",u.url),f.innerHTML=`
              <div style="flex: 1; min-width: 0;">
                <div class="doubao-plus-list-item-title" style="white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">
                  ${u.title}
                </div>
                <div style="font-size: 11px; color: #6b7280; margin-top: 2px;">
                  ${new Date(u.timestamp).toLocaleDateString()}
                </div>
              </div>
              <div class="doubao-plus-list-item-actions">
                <button class="doubao-plus-icon-btn" title="移出文件夹" data-action="removeFromFolder" data-chat-id="${u.id}">
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M5 12h14"/>
                  </svg>
                </button>
                <button class="doubao-plus-icon-btn" title="删除" data-action="delete" data-chat-id="${u.id}">
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M3 6h18M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a2 2 0 012-2h4a2 2 0 012 2v2"/>
                  </svg>
                </button>
              </div>
            `,l.appendChild(f),f.addEventListener("click",y=>{y.target.closest(".doubao-plus-icon-btn")||(window.location.href=u.url)})}),t.appendChild(s),s.insertAdjacentElement("afterend",l);const p=s.querySelector(".doubao-plus-folder-toggle");p==null||p.addEventListener("click",()=>{const u=l.style.display!=="none";l.style.display=u?"none":"block",p.innerHTML=u?`
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M9 18l6-6-6-6"/>
            </svg>
          `:`
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M6 9l6 6 6-6"/>
            </svg>
          `})}const r=o.querySelector("#create-folder-btn");r&&r.addEventListener("click",()=>T()),o.querySelectorAll(".doubao-plus-icon-btn").forEach(n=>{n.addEventListener("click",async s=>{s.stopPropagation();const l=n.getAttribute("data-action"),i=n.getAttribute("data-id"),d=n.getAttribute("data-chat-id");l==="edit"&&i?await v(l,i):l==="delete"&&i?await v(l,i):l==="removeFromFolder"&&d?await E(d):l==="delete"&&d&&(await chrome.runtime.sendMessage({action:"deleteChat",chatId:d})).status==="success"&&b("folders")})})}async function E(o){const t=((await chrome.runtime.sendMessage({action:"getChats"})).chats||[]).find(r=>r.id===o);t&&(t.folderId=null,await chrome.runtime.sendMessage({action:"saveChat",chat:t}),b("folders"))}async function S(o){const e=(await chrome.runtime.sendMessage({action:"getPrompts"})).prompts||[];o.innerHTML=`
    <div style="display: flex; gap: 8px; margin-bottom: 12px;">
      <input type="text" class="doubao-plus-search" placeholder="搜索提示词..." id="prompt-search">
    </div>
    <button class="doubao-plus-btn" style="width: 100%; margin-bottom: 12px;" id="create-prompt-btn">
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <path d="M12 5v14M5 12h14"/>
      </svg>
      创建提示词
    </button>
    <div id="prompts-list"></div>
  `;const t=o.querySelector("#prompts-list");t&&(e.length===0?t.innerHTML=`
        <div class="doubao-plus-empty">
          <p>暂无提示词</p>
        </div>
      `:e.forEach(s=>{const l=document.createElement("div");l.className="doubao-plus-list-item",l.innerHTML=`
          <div style="flex: 1; min-width: 0;">
            <div class="doubao-plus-list-item-title" style="white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">
              ${s.title}
            </div>
            <div style="font-size: 11px; color: #6b7280; margin-top: 2px;">
              <span class="doubao-plus-badge">${s.category}</span>
              <span style="margin-left: 8px;">使用 ${s.usageCount} 次</span>
            </div>
          </div>
          <div class="doubao-plus-list-item-actions">
            <button class="doubao-plus-icon-btn" title="使用" data-action="use" data-id="${s.id}">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M5 12h14M12 5l7 7-7 7"/>
              </svg>
            </button>
            <button class="doubao-plus-icon-btn" title="编辑" data-action="edit" data-id="${s.id}">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7"/>
                <path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"/>
              </svg>
            </button>
            <button class="doubao-plus-icon-btn" title="删除" data-action="delete" data-id="${s.id}">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M3 6h18M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a2 2 0 012-2h4a2 2 0 012 2v2"/>
              </svg>
            </button>
          </div>
        `,t.appendChild(l)}));const r=o.querySelector("#prompt-search");r&&r.addEventListener("input",s=>{const l=s.target.value.toLowerCase();o.querySelectorAll(".doubao-plus-list-item").forEach(d=>{var u,f;const p=((f=(u=d.querySelector(".doubao-plus-list-item-title"))==null?void 0:u.textContent)==null?void 0:f.toLowerCase())||"";d.style.display=p.includes(l)?"flex":"none"})});const n=o.querySelector("#create-prompt-btn");n&&n.addEventListener("click",()=>$()),o.querySelectorAll(".doubao-plus-icon-btn").forEach(s=>{s.addEventListener("click",async l=>{l.stopPropagation();const i=s.getAttribute("data-action"),d=s.getAttribute("data-id");i&&d&&await A(i,d)})})}async function q(o,a){(await chrome.runtime.sendMessage({action:"handleChatAction",chatAction:o,chatId:a})).status==="success"&&b("chats")}async function v(o,a){o==="edit"?I(a):o==="delete"&&confirm("确定要删除这个文件夹吗？")&&(await chrome.runtime.sendMessage({action:"deleteFolder",folderId:a})).status==="success"&&b("folders")}async function A(o,a){o==="use"?(await chrome.runtime.sendMessage({action:"usePrompt",promptId:a})).status==="success"&&b("prompts"):o==="edit"?B(a):o==="delete"&&confirm("确定要删除这个提示词吗？")&&(await chrome.runtime.sendMessage({action:"deletePrompt",promptId:a})).status==="success"&&b("prompts")}function T(){var t,r;if(!c.shadowRoot)return;const o=document.createElement("div");o.className="doubao-plus-modal",o.innerHTML=`
    <div class="doubao-plus-modal-content">
      <div class="doubao-plus-modal-title">创建文件夹</div>
      <div class="doubao-plus-modal-body">
        <div class="doubao-plus-form-group">
          <label class="doubao-plus-form-label">文件夹名称</label>
          <input type="text" class="doubao-plus-input" id="folder-name" placeholder="输入文件夹名称">
        </div>
        <div class="doubao-plus-form-group">
          <label class="doubao-plus-form-label">颜色</label>
          <div class="doubao-plus-color-picker" id="color-picker">
            <div class="doubao-plus-color-option selected" style="background: #0ea5e9" data-color="#0ea5e9"></div>
            <div class="doubao-plus-color-option" style="background: #ef4444" data-color="#ef4444"></div>
            <div class="doubao-plus-color-option" style="background: #f59e0b" data-color="#f59e0b"></div>
            <div class="doubao-plus-color-option" style="background: #10b981" data-color="#10b981"></div>
            <div class="doubao-plus-color-option" style="background: #3b82f6" data-color="#3b82f6"></div>
            <div class="doubao-plus-color-option" style="background: #6366f1" data-color="#6366f1"></div>
            <div class="doubao-plus-color-option" style="background: #8b5cf6" data-color="#8b5cf6"></div>
            <div class="doubao-plus-color-option" style="background: #ec4899" data-color="#ec4899"></div>
          </div>
        </div>
      </div>
      <div class="doubao-plus-modal-footer">
        <button class="doubao-plus-btn doubao-plus-btn-secondary" id="cancel-btn">取消</button>
        <button class="doubao-plus-btn" id="save-btn">创建</button>
      </div>
    </div>
  `,c.shadowRoot.appendChild(o);const a=o.querySelectorAll(".doubao-plus-color-option");let e="#0ea5e9";a.forEach(n=>{n.addEventListener("click",()=>{a.forEach(s=>s.classList.remove("selected")),n.classList.add("selected"),e=n.getAttribute("data-color")||"#0ea5e9"})}),(t=o.querySelector("#cancel-btn"))==null||t.addEventListener("click",()=>{o.remove()}),(r=o.querySelector("#save-btn"))==null||r.addEventListener("click",async()=>{console.log("Create folder button clicked");const s=o.querySelector("#folder-name").value.trim();if(console.log("Folder name:",s),console.log("Selected color:",e),!s){alert("请输入文件夹名称");return}console.log("Sending createFolder message to background...");const l=await chrome.runtime.sendMessage({action:"createFolder",name:s,color:e});console.log("Response from background:",l),l.status==="success"?(console.log("Folder created successfully, removing modal and reloading..."),o.remove(),b("folders")):(console.log("Failed to create folder:",l),alert("创建文件夹失败: "+(l.message||"未知错误")))})}function I(o){chrome.runtime.sendMessage({action:"getFolder",folderId:o}).then(a=>{var s,l;const e=a.folder;if(!e||!c.shadowRoot)return;const t=document.createElement("div");t.className="doubao-plus-modal",t.innerHTML=`
      <div class="doubao-plus-modal-content">
        <div class="doubao-plus-modal-title">编辑文件夹</div>
        <div class="doubao-plus-modal-body">
          <div class="doubao-plus-form-group">
            <label class="doubao-plus-form-label">文件夹名称</label>
            <input type="text" class="doubao-plus-input" id="folder-name" value="${e.name}">
          </div>
          <div class="doubao-plus-form-group">
            <label class="doubao-plus-form-label">颜色</label>
            <div class="doubao-plus-color-picker" id="color-picker">
              <div class="doubao-plus-color-option ${e.color==="#0ea5e9"?"selected":""}" style="background: #0ea5e9" data-color="#0ea5e9"></div>
              <div class="doubao-plus-color-option ${e.color==="#ef4444"?"selected":""}" style="background: #ef4444" data-color="#ef4444"></div>
              <div class="doubao-plus-color-option ${e.color==="#f59e0b"?"selected":""}" style="background: #f59e0b" data-color="#f59e0b"></div>
              <div class="doubao-plus-color-option ${e.color==="#10b981"?"selected":""}" style="background: #10b981" data-color="#10b981"></div>
              <div class="doubao-plus-color-option ${e.color==="#3b82f6"?"selected":""}" style="background: #3b82f6" data-color="#3b82f6"></div>
              <div class="doubao-plus-color-option ${e.color==="#6366f1"?"selected":""}" style="background: #6366f1" data-color="#6366f1"></div>
              <div class="doubao-plus-color-option ${e.color==="#8b5cf6"?"selected":""}" style="background: #8b5cf6" data-color="#8b5cf6"></div>
              <div class="doubao-plus-color-option ${e.color==="#ec4899"?"selected":""}" style="background: #ec4899" data-color="#ec4899"></div>
            </div>
          </div>
        </div>
        <div class="doubao-plus-modal-footer">
          <button class="doubao-plus-btn doubao-plus-btn-secondary" id="cancel-btn">取消</button>
          <button class="doubao-plus-btn" id="save-btn">保存</button>
        </div>
      </div>
    `,c.shadowRoot.appendChild(t);const r=t.querySelectorAll(".doubao-plus-color-option");let n=e.color;r.forEach(i=>{i.addEventListener("click",()=>{r.forEach(d=>d.classList.remove("selected")),i.classList.add("selected"),n=i.getAttribute("data-color")||"#0ea5e9"})}),(s=t.querySelector("#cancel-btn"))==null||s.addEventListener("click",()=>{t.remove()}),(l=t.querySelector("#save-btn"))==null||l.addEventListener("click",async()=>{const d=t.querySelector("#folder-name").value.trim();if(!d){alert("请输入文件夹名称");return}(await chrome.runtime.sendMessage({action:"updateFolder",folderId:o,name:d,color:n})).status==="success"&&(t.remove(),b("folders"))})})}function $(){var a,e;if(!c.shadowRoot)return;const o=document.createElement("div");o.className="doubao-plus-modal",o.innerHTML=`
    <div class="doubao-plus-modal-content">
      <div class="doubao-plus-modal-title">创建提示词</div>
      <div class="doubao-plus-modal-body">
        <div class="doubao-plus-form-group">
          <label class="doubao-plus-form-label">标题</label>
          <input type="text" class="doubao-plus-input" id="prompt-title" placeholder="输入提示词标题">
        </div>
        <div class="doubao-plus-form-group">
          <label class="doubao-plus-form-label">分类</label>
          <input type="text" class="doubao-plus-input" id="prompt-category" placeholder="输入分类（如：编程、写作等）">
        </div>
        <div class="doubao-plus-form-group">
          <label class="doubao-plus-form-label">内容</label>
          <textarea class="doubao-plus-textarea" id="prompt-content" placeholder="输入提示词内容"></textarea>
        </div>
      </div>
      <div class="doubao-plus-modal-footer">
        <button class="doubao-plus-btn doubao-plus-btn-secondary" id="cancel-btn">取消</button>
        <button class="doubao-plus-btn" id="save-btn">创建</button>
      </div>
    </div>
  `,c.shadowRoot.appendChild(o),(a=o.querySelector("#cancel-btn"))==null||a.addEventListener("click",()=>{o.remove()}),(e=o.querySelector("#save-btn"))==null||e.addEventListener("click",async()=>{const t=o.querySelector("#prompt-title"),r=o.querySelector("#prompt-category"),n=o.querySelector("#prompt-content"),s=t.value.trim(),l=r.value.trim()||"未分类",i=n.value.trim();if(!s||!i){alert("请输入标题和内容");return}(await chrome.runtime.sendMessage({action:"createPrompt",title:s,category:l,content:i})).status==="success"&&(o.remove(),b("prompts"))})}function B(o){chrome.runtime.sendMessage({action:"getPrompt",promptId:o}).then(a=>{var r,n;const e=a.prompt;if(!e||!c.shadowRoot)return;const t=document.createElement("div");t.className="doubao-plus-modal",t.innerHTML=`
      <div class="doubao-plus-modal-content">
        <div class="doubao-plus-modal-title">编辑提示词</div>
        <div class="doubao-plus-modal-body">
          <div class="doubao-plus-form-group">
            <label class="doubao-plus-form-label">标题</label>
            <input type="text" class="doubao-plus-input" id="prompt-title" value="${e.title}">
          </div>
          <div class="doubao-plus-form-group">
            <label class="doubao-plus-form-label">分类</label>
            <input type="text" class="doubao-plus-input" id="prompt-category" value="${e.category}">
          </div>
          <div class="doubao-plus-form-group">
            <label class="doubao-plus-form-label">内容</label>
            <textarea class="doubao-plus-textarea" id="prompt-content">${e.content}</textarea>
          </div>
        </div>
        <div class="doubao-plus-modal-footer">
          <button class="doubao-plus-btn doubao-plus-btn-secondary" id="cancel-btn">取消</button>
          <button class="doubao-plus-btn" id="save-btn">保存</button>
        </div>
      </div>
    `,c.shadowRoot.appendChild(t),(r=t.querySelector("#cancel-btn"))==null||r.addEventListener("click",()=>{t.remove()}),(n=t.querySelector("#save-btn"))==null||n.addEventListener("click",async()=>{const s=t.querySelector("#prompt-title"),l=t.querySelector("#prompt-category"),i=t.querySelector("#prompt-content"),d=s.value.trim(),p=l.value.trim()||"未分类",u=i.value.trim();if(!d||!u){alert("请输入标题和内容");return}(await chrome.runtime.sendMessage({action:"updatePrompt",promptId:o,title:d,category:p,content:u})).status==="success"&&(t.remove(),b("prompts"))})})}function g(){console.log("=== observePageChanges Started ===");const o=new MutationObserver(a=>{console.log("=== MutationObserver Callback ==="),console.log("Mutations count:",a.length);try{const e=h();console.log("After findSidebar, sidebar:",e),e&&!c.container&&(console.log("About to call injectDoubaoPlusUI..."),m(),console.log("After injectDoubaoPlusUI")),console.log("About to find input element...");const t=document.querySelector('textarea[placeholder*="豆包"]')||document.querySelector('textarea[placeholder*="发送"]')||document.querySelector('textarea[placeholder*="输入"]');console.log("Input element:",t),t&&!t.dataset.doubaoPlus&&(t.dataset.doubaoPlus="true",console.log("Found input element on page")),console.log("About to call addChatActionButtons..."),P(),console.log("Finished calling addChatActionButtons")}catch(e){console.error("Error in MutationObserver callback:",e),console.error("Error stack:",e.stack)}});c.observer=o,o.observe(document.body,{childList:!0,subtree:!0}),console.log("=== observePageChanges Observer Attached ===")}function P(){console.log("=== addChatActionButtons Debug ==="),console.log("Searching for chat items...");const o=document.querySelectorAll('[class*="chat-item"], [class*="ChatItem"], [class*="conversation-item"], [class*="ConversationItem"]');if(console.log("Found chat items:",o.length),console.log("Chat items:",o),o.length===0){console.log("No chat items found yet");const a=h();if(a){const e=a.querySelector("#flow_chat_sidebar");if(e){const t=e.querySelector('[data-testid="chat_list_wrapper"]');if(t){const r=t.children[1];if(r){const n=r.querySelectorAll("a.cursor-pointer");if(console.log("Found chat links:",n.length),n.length>0){console.log("Using chat links as chat items"),n.forEach(s=>{if(s.querySelector(".doubao-plus-chat-action"))return;const l=document.createElement("button");l.className="doubao-plus-chat-action",l.innerHTML=`
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <circle cx="12" cy="12" r="1"/>
                    <circle cx="12" cy="5" r="1"/>
                    <circle cx="12" cy="19" r="1"/>
                  </svg>
                `,l.style.cssText=`
                  background: transparent;
                  border: none;
                  cursor: pointer;
                  padding: 4px;
                  border-radius: 4px;
                  color: #9ca3af;
                  transition: all 0.2s;
                  opacity: 0.6;
                  margin-left: 8px;
                `,l.addEventListener("mouseenter",()=>{l.style.opacity="1",l.style.color="#3b82f6"}),l.addEventListener("mouseleave",()=>{l.style.opacity="0.6",l.style.color="#9ca3af"}),l.addEventListener("click",i=>{i.stopPropagation(),i.preventDefault(),x(l)}),s.appendChild(l)}),console.log("Added action buttons to",n.length,"chat items");return}}}}}return}o.forEach(a=>{if(a.querySelector(".doubao-plus-chat-action"))return;const e=document.createElement("button");e.className="doubao-plus-chat-action",e.innerHTML=`
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <circle cx="12" cy="12" r="1"/>
        <circle cx="12" cy="5" r="1"/>
        <circle cx="12" cy="19" r="1"/>
      </svg>
    `,e.style.cssText=`
      background: transparent;
      border: none;
      cursor: pointer;
      padding: 4px;
      border-radius: 4px;
      color: #9ca3af;
      transition: all 0.2s;
      opacity: 0.6;
      margin-left: 8px;
    `,e.addEventListener("mouseenter",()=>{e.style.opacity="1",e.style.color="#3b82f6"}),e.addEventListener("mouseleave",()=>{e.style.opacity="0.6",e.style.color="#9ca3af"}),e.addEventListener("click",t=>{t.stopPropagation(),t.preventDefault(),x(e)}),a.appendChild(e)}),console.log("Added action buttons to",o.length,"chat items")}function x(o){const a=document.querySelector(".doubao-plus-chat-menu");a&&a.remove();const e=document.createElement("div");e.className="doubao-plus-chat-menu",e.innerHTML=`
    <div class="doubao-plus-chat-menu-content">
      <div class="doubao-plus-chat-menu-item" data-action="save">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <path d="M19 21H5a2 2 0 00-2-2v-7a2 2 0 002 2h14a2 2 0 002-2v7"/>
        </svg>
        <span>保存对话</span>
      </div>
      <div class="doubao-plus-chat-menu-item" data-action="moveToFolder">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <path d="M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-6l-2-2H5a2 2 0 00-2 2z"/>
        </svg>
        <span>移动到文件夹</span>
      </div>
      <div class="doubao-plus-chat-menu-item" data-action="star">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
        </svg>
        <span>星标</span>
      </div>
      <div class="doubao-plus-chat-menu-item" data-action="delete">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <path d="M3 6h18M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a2 2 0 012-2h4a2 2 0 012 2v2"/>
        </svg>
        <span>删除</span>
      </div>
    </div>
  `,e.style.cssText=`
    position: fixed;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    background: white;
    border-radius: 12px;
    box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.2);
    z-index: 999999;
    min-width: 200px;
  `,document.body.appendChild(e),e.querySelectorAll(".doubao-plus-chat-menu-item").forEach(t=>{t.addEventListener("click",r=>{r.stopPropagation();const n=t.getAttribute("data-action"),s=o.closest('[class*="chat-item"], [class*="ChatItem"], [class*="conversation-item"], [class*="ConversationItem"]');s&&n&&H(n,s),e.remove()})}),setTimeout(()=>{const t=r=>{e.contains(r.target)||e.remove()};document.addEventListener("click",t,{once:!0})},100)}async function H(o,a){var s;console.log("=== Chat Item Action Debug ==="),console.log("Chat item element:",a),console.log("Chat item tagName:",a.tagName),console.log("Chat item class:",a.className),console.log("Chat item outerHTML:",a.outerHTML.substring(0,500));const e=a.querySelector('[class*="title"], [class*="Title"], h1, h2, h3, h4'),t=((s=e==null?void 0:e.textContent)==null?void 0:s.trim())||"未命名对话";console.log("Title:",t),console.log("All children:",Array.from(a.children).map(l=>({tagName:l.tagName,className:l.className,href:l.href})));let r=window.location.href;const n=a.querySelector("a[href]");switch(console.log("Link element:",n),n&&(r=n.href,console.log("Link href:",r)),console.log("Final URL:",r),console.log("=== End Debug ==="),o){case"save":const l={id:`${Date.now()}-${Math.random().toString(36).substr(2,9)}`,title:t,url:r,timestamp:Date.now(),starred:!1,messages:[]};await chrome.runtime.sendMessage({action:"saveChat",chat:l}),alert(`✅ 对话已保存到Doubao Plus！

您可以在Doubao Plus面板的"对话"标签中查看和管理保存的对话。`);break;case"moveToFolder":await F(t,r);break;case"star":alert("星标功能需要在保存的对话中使用");break;case"delete":confirm("确定要删除这个对话吗？")&&(await chrome.runtime.sendMessage({action:"deleteChat",chatId:l.id})).status==="success"&&alert("对话已删除");break}}async function F(o,a){const t=(await chrome.runtime.sendMessage({action:"getFolders"})).folders||[];if(t.length===0){alert("还没有创建文件夹，请先创建文件夹");return}z(o,a,t)}function z(o,a,e){var n;const t=document.querySelector(".doubao-plus-folder-modal");t&&t.remove();const r=document.createElement("div");r.className="doubao-plus-folder-modal",r.innerHTML=`
    <div class="doubao-plus-modal-content">
      <div class="doubao-plus-modal-title">选择文件夹</div>
      <div class="doubao-plus-modal-body">
        <div style="margin-bottom: 12px; font-size: 13px; color: #6b7280;">
          将对话 "${o}" 移动到：
        </div>
        <div id="folder-list" style="max-height: 300px; overflow-y: auto;">
          ${e.map(s=>`
            <div class="doubao-plus-folder-option" data-folder-id="${s.id}">
              <div class="doubao-plus-folder-color" style="background: ${s.color}"></div>
              <div class="doubao-plus-folder-name">${s.name}</div>
            </div>
          `).join("")}
        </div>
      </div>
      <div class="doubao-plus-modal-footer">
        <button class="doubao-plus-btn doubao-plus-btn-secondary" id="cancel-btn">取消</button>
      </div>
    </div>
  `,r.style.cssText=`
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0, 0, 0, 0.5);
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 999999;
  `,document.body.appendChild(r),r.querySelectorAll(".doubao-plus-folder-option").forEach(s=>{s.style.cssText=`
      display: flex;
      align-items: center;
      gap: 8px;
      padding: 10px 12px;
      margin-bottom: 6px;
      background: #ffffff;
      border: 1px solid #e5e7eb;
      border-radius: 6px;
      cursor: pointer;
      transition: all 0.2s;
    `,s.addEventListener("mouseenter",()=>{s.style.background="#f9fafb",s.style.borderColor="#3b82f6"}),s.addEventListener("mouseleave",()=>{s.style.background="#ffffff",s.style.borderColor="#e5e7eb"}),s.addEventListener("click",async()=>{const l=s.getAttribute("data-folder-id");if(l){const i={id:`${Date.now()}-${Math.random().toString(36).substr(2,9)}`,title:o,url:a,timestamp:Date.now(),starred:!1,messages:[],folderId:l},d=await chrome.runtime.sendMessage({action:"saveChat",chat:i});d.status==="success"?(r.remove(),alert(`✅ 对话已保存到文件夹！

您可以在Doubao Plus面板的"文件夹"标签中查看。`)):alert("保存失败: "+(d.message||"未知错误"))}})}),(n=r.querySelector("#cancel-btn"))==null||n.addEventListener("click",()=>{r.remove()}),setTimeout(()=>{const s=l=>{r.contains(l.target)||r.remove()};document.addEventListener("click",s,{once:!0})},100)}document.readyState==="loading"?document.addEventListener("DOMContentLoaded",()=>{g(),setTimeout(m,1e3)}):(g(),setTimeout(m,1e3));
